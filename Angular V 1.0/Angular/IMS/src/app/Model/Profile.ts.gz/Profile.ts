export interface Profile {
    employeeACEId: string;
    employeeDepartment: string;
    employeeEmailID: string;
    employeeName: string;
    employeeProject: string;
    employeeRole: string;
}