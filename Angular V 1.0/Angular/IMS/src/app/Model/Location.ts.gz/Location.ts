export interface Location{
    locationId:number,
    locationName:string,
    isActive:boolean,
    drivesUnderLocation:[]
}