export interface Role{
    roleId:number,
    roleName:string,
    isActive:boolean,
    employeesUnderRole:[]
}