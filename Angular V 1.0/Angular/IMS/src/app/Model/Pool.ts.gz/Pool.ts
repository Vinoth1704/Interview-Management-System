export interface Pool{
    poolId: number,
    poolName: string,
    departmentId: number,
    isActive: boolean,
    department: string,
    poolMembers: [],
    drivesUnderPool: null
}